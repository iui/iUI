<ul title="Search Results">
    <li><a href="#player">Songs (by <?php echo $_POST['artist']; ?>)</a></li>
    <li><a href="#player">Albums (by <?php echo $_POST['artist']; ?>)</a></li>
</ul>