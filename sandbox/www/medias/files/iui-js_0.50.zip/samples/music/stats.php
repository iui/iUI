
<!-- Sleep so users see the activity indicator -->
<?php sleep(2); ?>

<ul id="stats" title="Stats">
    <li><a href="#usage">Usage</a></li>
    <li><a href="#battery">Battery</a></li>
</ul>
    
<div id="usage" title="Usage" class="panel">
    <h2>Play Time</h2>
    <fieldset>
        <div class="row">
            <label>Years</label>
            <span>2</span>
        </div>
        <div class="row">
            <label>Months</label>
            <span>8</span>
        </div>
        <div class="row">
            <label>Days</label>
            <span>27</span>
        </div>
    </fieldset>
</div>

<div id="battery" title="Battery" class="panel">
    <h2>Better recharge soon!</h2>
</div>
