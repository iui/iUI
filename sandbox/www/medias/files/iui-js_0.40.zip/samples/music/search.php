<ul title="Search Results">
    <li><a href="#player">Song (by <?php echo $_POST['artist']; ?>)</a></li>
    <li><a href="#player">Song (by <?php echo $_POST['artist']; ?>)</a></li>
    <li><a href="#player">Song (by <?php echo $_POST['artist']; ?>)</a></li>
</ul>